package com.hirocode.story.utils

const val SETTINGS = "settings"